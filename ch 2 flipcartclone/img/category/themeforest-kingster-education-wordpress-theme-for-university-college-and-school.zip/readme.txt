This version is ‘3.0.3'
============================================================

Theme’s instruction is in the folder ‘document-instruction’. Please open that folder and open the file ‘index.html’ with your browsers.

============================================================

Changelog: https://support.goodlayers.com/document/changelog-kingster/